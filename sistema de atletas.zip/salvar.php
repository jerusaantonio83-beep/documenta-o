<?php
include('config.php');

$nome       = $_POST['nome'];
$municipio      = $_POST['município'];
$numero_atletas = $_POST['numero de atletas'];

$sql = "INSERT INTO atletas (nome, municipio, numero_atletas) 
        VALUES ('$nome', '$municipio', '$numero_atletas')";

if ($conn->query($sql) === TRUE) {
    echo "Atleta cadastrado com sucesso!";
} else {
    echo "Erro: " . $conn->error;
}

$conn->close();
?>
