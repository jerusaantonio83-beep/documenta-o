<?php
include('config.php');

echo "Conexão feita com sucesso";
?>
